Version 4
SymbolType BLOCK
LINE Normal -40 -8 -40 -24
LINE Normal -32 -8 -40 -8
LINE Normal -40 8 -32 -8
LINE Normal -48 -8 -40 8
LINE Normal -40 -8 -48 -8
LINE Normal -40 24 -40 -8
LINE Normal 16 -40 8 -40
LINE Normal 8 -24 16 -40
LINE Normal 0 -40 8 -24
LINE Normal 8 -40 0 -40
LINE Normal 8 -8 8 -40
LINE Normal 8 -8 8 -24
LINE Normal 16 -8 8 -8
LINE Normal 8 8 16 -8
LINE Normal 0 -8 8 8
LINE Normal 8 -8 0 -8
LINE Normal 8 24 8 -8
LINE Normal 8 24 8 8
LINE Normal 16 24 8 24
LINE Normal 8 40 16 24
LINE Normal 0 24 8 40
LINE Normal 8 24 0 24
LINE Normal 8 -40 8 -48
LINE Normal 8 48 8 -40
LINE Normal 48 -48 8 -48
LINE Normal 48 48 8 48
LINE Normal -40 -48 -40 -24
LINE Normal -80 -48 -40 -48
LINE Normal -40 48 -40 24
LINE Normal -80 48 -40 48
LINE Normal 48 -48 96 -48
LINE Normal 48 48 96 48
LINE Normal 48 -48 48 -32
LINE Normal 48 48 48 32
LINE Normal -8 -4 -24 -4
LINE Normal -11 -7 -8 -4
LINE Normal -11 -2 -11 -7
LINE Normal -11 -1 -11 -2
LINE Normal -8 -4 -11 -1
LINE Normal -8 4 -24 4
LINE Normal -11 1 -8 4
LINE Normal -11 6 -11 1
LINE Normal -11 7 -11 6
LINE Normal -8 4 -11 7
LINE Normal -48 8 -40 8
LINE Normal -32 8 -48 8
LINE Normal 0 -24 8 -24
LINE Normal 16 -24 0 -24
LINE Normal 16 8 0 8
LINE Normal 0 40 8 40
LINE Normal 16 40 0 40
RECTANGLE Normal 80 64 -64 -64
RECTANGLE Normal 64 32 32 -32
TEXT 48 -16 Top 0 Turn
TEXT 48 16 Bottom 0 Off
WINDOW 0 -32 -64 Bottom 2
WINDOW 3 8 64 Top 2
SYMATTR Value VOM1271
SYMATTR Prefix X
SYMATTR ModelFile VOM1271.lib
PIN -80 -48 NONE 8
PINATTR PinName A
PINATTR SpiceOrder 1
PIN -80 48 NONE 8
PINATTR PinName K
PINATTR SpiceOrder 2
PIN 96 -48 NONE 8
PINATTR PinName +Iout
PINATTR SpiceOrder 3
PIN 96 48 NONE 8
PINATTR PinName -Iout
PINATTR SpiceOrder 4
